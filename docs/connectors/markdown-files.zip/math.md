# Math Connector

![Math](./assets/math.png#connector-icon)
Perform common math operations on numbers or lists of numbers

## Actions

### Absolute Value {#abs}

Returns the absolute value of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Add Numbers {#add}

Returns the result of adding the numbers

| Input   | Comments | Default |
| ------- | -------- | ------- |
| Numbers |          |         |

### Arccosine {#acos}

Returns the arccosine of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Arcsine {#asin}

Returns the arcsine of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Arctangent {#atan}

Returns the arctangent of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Ceiling {#ceil}

Returns the smallest integer greater than or equal to the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Cosine {#cos}

Returns the cosine of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Cube Root {#cbrt}

Returns the cube root of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Divide Numbers {#divide}

Returns the result of dividing the numbers

| Input   | Comments | Default |
| ------- | -------- | ------- |
| Numbers |          |         |

### Evaluate Expression {#evaluate}

Evaluate a mathematical expression (for example, "2 \* 3 + 7")

| Input      | Comments | Default |
| ---------- | -------- | ------- |
| Expression |          |         |

### e^x {#exp}

Returns e^x, where x is the input number, and e is Euler's constant (2.718…, the base of the natural logarithm).

| Input    | Comments                                 | Default |
| -------- | ---------------------------------------- | ------- |
| Exponent | A number to provide to the math function |         |

### Float-round {#fround}

Returns the nearest single precision float representation of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Floor {#floor}

Returns the largest integer less than or equal to the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Hyperbolic Arccosine {#acosh}

Returns the hyperbolic arccosine of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Hyperbolic Arcsine {#asinh}

Returns the hyperbolic arcsine of a number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Hyperbolic Arctangent {#atanh}

Returns the hyperbolic arctangent of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Hyperbolic Cosine {#cosh}

Returns the hyperbolic cosine of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Hyperbolic Sine {#sinh}

Returns the hyperbolic sine of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Hyperbolic Tangent {#tanh}

Returns the hyperbolic tangent of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Hypotenuse {#hypot}

Returns the square root of the sum of squares of an array of numbers.

| Input   | Comments | Default |
| ------- | -------- | ------- |
| Numbers |          |         |

### Logarithm {#log}

Returns the logarithm of a given input base of an input number.

| Input         | Comments                                 | Default |
| ------------- | ---------------------------------------- | ------- |
| Number        | A number to provide to the math function |         |
| Exponent Base |                                          | 10      |

### Maximum {#max}

Returns the largest of zero or more numbers.

| Input           | Comments                                                                                                                                                             | Default |
| --------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------- |
| Numbers         |                                                                                                                                                                      |         |
| Dynamic Numbers | Use this input to provide numbers in JSON format, rather than using the default 'Numbers' input. Please note that using this input takes precedence over said input. |         |

### Minimum {#min}

Returns the smallest of zero or more numbers.

| Input           | Comments                                                                                                                                                             | Default |
| --------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------- |
| Numbers         |                                                                                                                                                                      |         |
| Dynamic Numbers | Use this input to provide numbers in JSON format, rather than using the default 'Numbers' input. Please note that using this input takes precedence over said input. |         |

### Multiply Numbers {#multiply}

Returns the result of multiplying the numbers

| Input   | Comments | Default |
| ------- | -------- | ------- |
| Numbers |          |         |

### Natural Log {#naturallog}

Returns the natural logarithm (log e; also, ln) of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Power {#pow}

Returns base x to the exponent power y (that is, x^y).

| Input    | Comments                                 | Default |
| -------- | ---------------------------------------- | ------- |
| Base     | A number to provide to the math function |         |
| Exponent | A number to provide to the math function |         |

### Random Integer {#randomint}

Returns a pseudo-random integer between min and max.

| Input | Comments                                 | Default |
| ----- | ---------------------------------------- | ------- |
| Min   | A number to provide to the math function |         |
| Max   | A number to provide to the math function |         |

### Random Number {#random}

Returns a pseudo-random number between min and max.

| Input | Comments                                 | Default |
| ----- | ---------------------------------------- | ------- |
| Min   | A number to provide to the math function |         |
| Max   | A number to provide to the math function |         |

### Round {#round}

Returns the value of the input number rounded to the nearest integer.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Sine {#sin}

Returns the sine of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Square Root {#sqrt}

Returns the positive square root of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Subtract Numbers {#subtract}

Returns the result of subtracting the numbers

| Input   | Comments | Default |
| ------- | -------- | ------- |
| Numbers |          |         |

### Tangent {#tan}

Returns the tangent of the input number.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |

### Truncate Number {#trunc}

Returns the integer portion of the input number, removing any fractional digits.

| Input  | Comments                                 | Default |
| ------ | ---------------------------------------- | ------- |
| Number | A number to provide to the math function |         |
