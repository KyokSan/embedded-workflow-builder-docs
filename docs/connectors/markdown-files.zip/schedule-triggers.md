# Schedule Trigger Connector

![Schedule Trigger](./assets/schedule-triggers.png#connector-icon)
The schedule trigger allows you to invoke a flow on a recurring custom schedule.

## Triggers

### Schedule {#schedule}

Invoke a flow on a recurring custom schedule.
