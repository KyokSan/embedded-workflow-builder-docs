# UUID Connector

![UUID](./assets/uuid.png#connector-icon)
Generate UUIDs and GUIDs

## Actions

### Generate UUID {#generateuuid}

Generate a version 4 UUID / GUID

| Input                   | Comments | Default |
| ----------------------- | -------- | ------- |
| Lower / Upper Case UUID |          | lower   |
| Remove dashes?          |          | false   |

### Nil/Empty UUID {#emptyuuid}

Return the nil / empty UUID (00000000-0000-0000-0000-000000000000)
