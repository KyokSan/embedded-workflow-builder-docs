# Result Placeholder Connector

![Result Placeholder](./assets/result-placeholder.png#connector-icon)
Generate a step output

## Actions

### Mock Result {#actions}

Generate a step result of your choosing.

| Input | Comments                                                                                                                                | Default |
| ----- | --------------------------------------------------------------------------------------------------------------------------------------- | ------- |
| Code  | This input will be returned as a string, unless valid JSON is provided, in which case it will be deserialized into a JavaScript object. |         |
